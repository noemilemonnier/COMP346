package task5;

import common.Semaphore;

/*
 ***********************************************************************************************************************************
 * Noemi Lemonnier
 * Student ID 40001085
 * Assignment 2
 ***********************************************************************************************************************************
 */

class BlockStack5
{
	

	/**
	 * # of letters in the English alphabet + 2
	 */
	public static final int MAX_SIZE = 28;

	/**
	 * Default stack size
	 */
	public static final int DEFAULT_SIZE = 6;

	/**
	 * Current size of the stack
	 */
	private int iSize = DEFAULT_SIZE;

	/**
	 * Current top of the stack
	 */
	private int iTop  = 3;

	/*
	 * Stack Access counter 
	 */
	private int accessCounter = 0;

	public int size;
	/**
	 * stack[0:5] with four defined values
	 */
	public char acStack[] = new char[] {'a', 'b', 'c', 'd', '$', '$'};

	/**
	 * Default constructor
	 */
	public BlockStack()
	{
	}

	/**
	 * Supplied size
	 */
	public BlockStack(final int piSize)
	{


		if(piSize != DEFAULT_SIZE)
		{
			this.acStack = new char[piSize];

			// Fill in with letters of the alphabet and keep
			// 2 free blocks
			for(int i = 0; i < piSize - 2; i++)
				this.acStack[i] = (char)('a' + i);

			this.acStack[piSize - 2] = this.acStack[piSize - 1] = '$';

			this.iTop = piSize - 3;
			this.iSize = piSize;
		}
	}

	/**
	 * Picks a value from the top without modifying the stack
	 * @return top element of the stack, char
	 * @throws StackException 
	 */
	public char pick() throws StackException
	{
		this.accessCounter++;
		size = this.getiTop();
		if(this.isEmpty() == false){
			return this.acStack[size];
		}
		else{
			throw new StackException ("The Stack is Empty");
		}
		
	}

	/**
	 * Returns arbitrary value from the stack array
	 * @return the element, char
	 * @throws StackException 
	 */
	public char getAt(final int piPosition) throws StackException
	{
		this.accessCounter++;
		if(piPosition <= this.getiSize() - 1)
			return this.acStack[piPosition];
		
		else
			throw new StackException ("This position could not be accessed");
		
		
	}

	/**
	 * Standard push operation
	 * @throws StackException 
	 */
	public void push(final char pcBlock) throws StackException
	{
		this.accessCounter++;
		size = this.getiTop();
		// if the stack is empty
		if(this.isEmpty() == true){
			this.acStack[this.getiTop()] = 'a'; // adds a as current top if stack is empty
		}
		//if the stack is full
		if(this.isFull() == true){
			throw new StackException ("The Stack is Full");
		}

		this.acStack[++size] = pcBlock;

		
	}

	/**
	 * Standard pop operation
	 * @return ex-top element of the stack, char
	 */
	public char pop() throws StackException
	{
		this.accessCounter++;
		size = this.getiTop();
		char cBlock = this.acStack[size];
		if(this.isEmpty() == true){
			throw new StackException ("The Stack is Empty");
		}
		this.acStack[size--] = '$'; // Leave prev. value undefined
		
		return cBlock;

	}

	public int getiSize() {
		return this.iSize;
	}

	public int getiTop() {
		return this.iTop;
	}
	public int getAccessCounter() {
		return this.accessCounter;
	}

	public boolean isEmpty()
	{
		size = this.getiTop();
		return (size == -1);
	}
	public boolean isFull()
	{
		if(this.getiTop()== this.acStack.length)
			return true;
		else
			return false;
	}

}

// EOF

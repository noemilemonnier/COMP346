
/*
 * Class created for the stack if it is full or empty
 */
public class StackException extends Exception{

	public StackException(String txt) {
		super(txt);
		System.err.println(txt);
	
	}

}

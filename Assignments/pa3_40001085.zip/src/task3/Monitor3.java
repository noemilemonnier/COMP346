package task3;
/**
 * Class Monitor
 * To synchronize dining philosophers.
 *
 * @author Serguei A. Mokhov, mokhov@cs.concordia.ca
 * 
 * Noémi Lemonnier #40001085
 * COMP346-W     PA #3
 */
public class Monitor3
{
	/*
	 * ------------
	 * Data members
	 * ------------
	 */
	//checks if a philosopher is talking
	private boolean isPhilosopherTalking = false;
	//number of philosophers
	private int numberOfPhilosophers;
	//number of chopsticks being used
	Chopsticks3[] chopsticks;


	/**
	 * Constructor
	 */
	public Monitor3(int piNumberOfPhilosophers)
	{
		// TODO: set appropriate number of Chopsticks based on the # of philosophers
		//set the numberOfPhilosophers to the number inputed
		numberOfPhilosophers = piNumberOfPhilosophers;
		//set size of the array to the number of philosophers
		chopsticks = new Chopsticks3[piNumberOfPhilosophers];
		// initialize each  object of the array as a new Chopsticks object
		for(int i = 0; i < chopsticks.length; i++)
		{
			chopsticks[i] = new Chopsticks3();
		}

	}

	/*
	 * -------------------------------
	 * User-defined monitor procedures
	 * -------------------------------
	 */

	/**
	 * Grants request (returns) to eat when both chopsticks/forks are available.
	 * Else forces the philosopher to wait()
	 */
	public synchronized void pickUp(final int piTID)
	{
		//get values of index in the array of Chopsticks on the left and right of the given philosopher
		int left = piTID - 1;
		int right= piTID;

		try {
			while(true){
				//if the chopstick  on the LEFT and on the RIGHT of the given philosopher are already picked up
				if(chopsticks[left].isPickedUpByAnother(piTID) || chopsticks[(right) % numberOfPhilosophers].isPickedUpByAnother(piTID)) 
				{
					//if the chopsticks on the LEFT  of the given philosopher are not used/not picked up
					if(!chopsticks[left].isPickedUp() && !chopsticks[left].isLastChopsticksPickedBy(piTID))
					{
						//then the given philosopher will pick chopsticks (LEFT)
						chopsticks[left].pickUp(piTID);
					} 	
					//if the chopsticks on the RIGHT of the given philosopher are not used/not picked up
					else if(!chopsticks[(right) % numberOfPhilosophers].isPickedUp() && !chopsticks[(right) % numberOfPhilosophers].isLastChopsticksPickedBy(piTID))
					{
						//then the  philosopher after the given one  will pick chopsticks (RIGHT)
						chopsticks[(right) % numberOfPhilosophers].pickUp(piTID);
					}
				} 

				//if both chopsticks are available
				else
				{
					//given philosopher can pick up the chopsticks
					//the one on the left
					chopsticks[left].pickUp(piTID);
					//the one on the right
					chopsticks[(right) % numberOfPhilosophers].pickUp(piTID);
					break; //goes out of the loop
				}

				wait();
			} 
		}catch (InterruptedException e) {
			System.err.println("Monitor.pickUp():");
			DiningPhilosophers3.reportException(e);
			System.exit(1);
		}
	}




	/**
	 * When a given philosopher's done eating, they put the chopstiks/forks down
	 * and let others know they are available.
	 */
	public synchronized void putDown(final int piTID)
	{
		try {
			//get values of index in the array of Chopsticks on the left and right of the given philosopher
			int left = piTID - 1;
			int right= piTID;
			//puts down both chopsticks
			chopsticks[left].putDown();
			chopsticks[(right) % numberOfPhilosophers].putDown();

			//notify all other philosophers
			notifyAll();


		} catch (Exception e) { //if any exception 
			System.err.println("Monitor2.putDown():");
			DiningPhilosophers3.reportException(e);
			System.exit(1);
		}
	}

	/**
	 * Only one philopher at a time is allowed to philosophy
	 * (while she is not eating).
	 */
	public synchronized void requestTalk(){
		try {

			//if any philosopher is talking
			while (isPhilosopherTalking == true) {
				wait();
			}

			//if no philosopher is talking, then you can talk
			isPhilosopherTalking = true;

		} catch (InterruptedException e) {
			System.err.println("Monitor2.requestTalk():");
			DiningPhilosophers3.reportException(e);
			System.exit(1);
		}
	}

	/**
	 * When one philosopher is done talking stuff, others
	 * can feel free to start talking.
	 */
	public synchronized void endTalk()
	{
		//if no philosopher is talking
		isPhilosopherTalking = false;
		//notify all other philosophers
		notifyAll();

	}
}

// EOF

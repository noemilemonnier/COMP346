/*
 * Noémi Lemonnier #40001085
 * COMP346-W     PA #3
 * This class was created for task 2 to check how many chopsticks are available
 */
package task3;

public class Chopsticks3 {

	private boolean isPickedUp;
	private int lastisPickedUpBy;

	// Default constructor
	public Chopsticks3()
	{
		isPickedUp = false;
		lastisPickedUpBy = 0;
	}
	/*
	 * Getters and Setters
	 */
	public boolean isPickedUp() {
		return isPickedUp;
	}

	public void setPickedUp(boolean isPickedUp) {
		this.isPickedUp = isPickedUp;
	}

	public int getLastisPickedUpBy() {
		return lastisPickedUpBy;
	}

	public void setLastisPickedUpBy(int lastisPickedUpBy) {
		this.lastisPickedUpBy = lastisPickedUpBy;
	}

	/*
	 * This method will set which philosopher last picked up the chopsticks
	 */
	public void pickUp(final int piTID)
	{
		isPickedUp = true;
		lastisPickedUpBy = piTID;
	}

	/*
	 * This method will set the boolean to false because the chopsticks are not being used.
	 */
	public void putDown()
	{
		isPickedUp = false;
	}
	
	/*
	 * This method will check which philosopher picked up the last chopsticks
	 */
	public boolean isLastChopsticksPickedBy(final int piTID)
	{
		return lastisPickedUpBy == piTID;
	}

	
	/*
	 * This method will check if the philosopher inputed did picked up chopsticks or not
	 */
	public boolean isPickedUpByAnother(final int piTID)
	{
		return ((isPickedUp == true) && (lastisPickedUpBy != piTID));
	}

	
	

}

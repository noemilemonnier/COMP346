package task3;

import java.io.BufferedReader;
import java.io.*;

/**
 * Class DiningPhilosophers
 * The main starter.
 *
 * @author Serguei A. Mokhov, mokhov@cs.concordia.ca
 * 
 * 
 * Noémi Lemonnier #40001085
 * COMP346-W     PA #3
 */
public class DiningPhilosophers3
{
	/*
	 * ------------
	 * Data members
	 * ------------
	 */

	/**
	 * This default may be overridden from the command line
	 */
	public static final int DEFAULT_NUMBER_OF_PHILOSOPHERS = 4;

	/**
	 * Dining "iterations" per philosopher thread
	 * while they are socializing there
	 */
	public static final int DINING_STEPS = 10;

	/**
	 * Our shared monitor for the philosphers to consult
	 */
	public static Monitor3 soMonitor = null;

	/*
	 * -------
	 * Methods
	 * -------
	 */

	/**
	 * Main system starts up right here
	 */
	public static void main(String[] argv)
	{
		try {
			/*
			 * Using scanner to get information from user
			 */
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Please enter a number of philosophers:");
			String inputString;
			int iPhilosophers;
			inputString = br.readLine();

			/*
			 * If user does not enter any numbers
			 */
			if(inputString.length() == 0){
				System.out.println("You have selected the default number of philosophers!");
				
				//if it is default
				iPhilosophers = DEFAULT_NUMBER_OF_PHILOSOPHERS;
				
				// Make the monitor aware of how many philosophers there are
				soMonitor = new Monitor3(iPhilosophers);

				// Space for all the philosophers
				Philosopher3 aoPhilosophers[] = new Philosopher3[iPhilosophers];

				// Let 'em sit down
				for(int j = 0; j < iPhilosophers; j++)
				{
					aoPhilosophers[j] = new Philosopher3();
					aoPhilosophers[j].start();
				}

				System.out.println
				(
						iPhilosophers +
						" philosopher(s) came in for a dinner."
						);

				// Main waits for all its children to die...
				// I mean, philosophers to finish their dinner.
				for(int j = 0; j < iPhilosophers; j++)
					aoPhilosophers[j].join();

				System.out.println("All philosophers have left. System terminates normally.");
			}
			
			/*
			 * If user enter a number or smthing else
			 */
			else{
				//transforms input into a integer
				int inpt = Integer.parseInt(inputString);
				
				//if the input is a valid postif number
				if(inpt>0){
					
					System.out.println("You have entered: " + inpt);
					
					iPhilosophers = inpt;
					
					// Make the monitor aware of how many philosophers there are
					soMonitor = new Monitor3(iPhilosophers);

					// Space for all the philosophers
					Philosopher3 aoPhilosophers[] = new Philosopher3[iPhilosophers];

					// Let 'em sit down
					for(int j = 0; j < iPhilosophers; j++)
					{
						aoPhilosophers[j] = new Philosopher3();
						aoPhilosophers[j].start();
					}

					System.out.println
					(
							iPhilosophers +
							" philosopher(s) came in for a dinner."
							);

					// Main waits for all its children to die...
					// I mean, philosophers to finish their dinner.
					for(int j = 0; j < iPhilosophers; j++)
						aoPhilosophers[j].join();

					System.out.println("All philosophers have left. System terminates normally.");
				}

				// if the user enter a negative number or anything else
				else{
					throw new NumberFormatException(inputString);

				}


			}
		}
		catch (NumberFormatException e1) {
			System.err.println(e1.getMessage() + " is not a positive decimal integer");
			System.err.println("Usage: java DiningPhilosophers [NUMBER_OF_PHILOSOPHERS]");
			System.exit(1);	
			e1.printStackTrace();
		}
		catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		catch(InterruptedException e)
		{
			System.err.println("main():");
			reportException(e);
			System.exit(1);
		}
	} // main()

	/**
	 * Outputs exception information to STDERR
	 * @param poException Exception object to dump to STDERR
	 */
	public static void reportException(Exception poException)
	{
		System.err.println("Caught exception : " + poException.getClass().getName());
		System.err.println("Message          : " + poException.getMessage());
		System.err.println("Stack Trace      : ");
		poException.printStackTrace(System.err);
	}
}

// EOF
